# Calm Sleep — Shopify Theme

This theme reorganizes the captured Calm Sleep website into Shopify's theme structure.

## Included
- Shopify `layout/theme.liquid`
- Shopify `templates/index.json`
- Main homepage section in `sections/main-home.liquid`
- Captured CSS, JavaScript chunks, images, product imagery, fonts and favicon in `assets/`

## Important
The homepage is currently rendered from the captured HTML so the visual design loads reliably in Shopify. The captured Vinext/React runtime chunks are included in `assets/` but are not booted automatically because the original site depends on its server-side RSC payload, which Shopify does not provide.

The black loading screen is set to the loaded state in the static Shopify render so the page does not get stuck behind the loader.

## GitHub / Shopify
Push the contents of this folder to the root of a GitHub repository. In Shopify, use Online Store → Themes → Add theme → Connect from GitHub, then select the repository and branch.
